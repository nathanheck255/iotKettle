import time

def customCallback(client,userdata,message):
    print("callback came...")
    print(message.payload)

from AWSIoTPythonSDK.MQTTLib import AWSIoTMQTTClient

myMQTTClient = AWSIoTMQTTClient("JoeComputer")
myMQTTClient.configureEndpoint("a2sxi23t654h6m-ats.iot.us-east-1.amazonaws.com", 8883)
myMQTTClient.configureCredentials("./AmazonRootCA1.pem","./ba5bac6c2092529549b5d5adfe683961003160e7fb508ff5545f53b4d9ec5562-private.pem.key", "./ba5bac6c2092529549b5d5adfe683961003160e7fb508ff5545f53b4d9ec5562-certificate.pem.crt.txt")

myMQTTClient.connect()
print("Client Connected")

myMQTTClient.subscribe("esp32/pub", 0, customCallback)
print('waiting for the callback. Click to conntinue...')
x = input()

myMQTTClient.unsubscribe("esp32/pub")
print("Client unsubscribed") 


myMQTTClient.disconnect()
print("Client Disconnected")