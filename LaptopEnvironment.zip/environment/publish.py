from AWSIoTPythonSDK.MQTTLib import AWSIoTMQTTClient
import sys

myMQTTClient = AWSIoTMQTTClient("JoeComputer")

myMQTTClient.configureEndpoint("a2sxi23t654h6m-ats.iot.us-east-1.amazonaws.com", 8883)
myMQTTClient.configureCredentials("./AmazonRootCA1.pem","./ba5bac6c2092529549b5d5adfe683961003160e7fb508ff5545f53b4d9ec5562-private.pem.key", "./ba5bac6c2092529549b5d5adfe683961003160e7fb508ff5545f53b4d9ec5562-certificate.pem.crt.txt")

myMQTTClient.connect()
print("Client Connected")

msg = "Sample data from the device1";
topic = "esp32/pub"
myMQTTClient.publish(topic, msg, 0)  
print("Message Sent")

myMQTTClient.disconnect()
print("Client Disconnected")